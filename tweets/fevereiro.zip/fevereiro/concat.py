import os
import pandas as pd 

files = os.listdir() 
file_list = list() 
for file in os.listdir():
    if file.endswith(".csv") and not file.endswith('all.csv'):
        df=pd.read_csv(file,sep=",")
        df['filename'] = file
        file_list.append(df) 
all = pd.concat(file_list, axis=0, ignore_index=True) 
all.to_csv("all.csv", index=False)
